<?php

return [
    'title_h1' => 'Дашборд'
    ,'points' => 'Точкуване'
    ,'see_more' => 'Виж повече'
    ,'levels' => 'Нива'
    ,'missions' => 'Мисии'
    ,'monsters' => 'Чудовища'
];