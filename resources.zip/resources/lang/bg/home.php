<?php

return [
    'title_h1' => 'Чудовища на Успеха'
    ,'main_title' => 'Забавлявай се - Учи - Печели'
    ,'footer_copyright' => 'Чудовища на Успехa 2016'
];