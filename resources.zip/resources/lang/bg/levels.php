<?php

return [
    'levels_title' => 'Задайте ниво'
    ,'number' => 'Номер:'
    ,'level' => 'Ниво:'
    ,'add_level' => 'Добави ниво'
    
    ,'table_title' => 'Списък с нива:'
    ,'table_number' => 'Номер'
    ,'table_levels' => 'Нива'
    ,'table_delete' => 'Изтрий'
    ,'td_delete' => 'Изтрий'
];