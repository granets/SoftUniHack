<?php

return [
    'login' => 'Вход'
    ,'email' => 'Ел. поща:'
    ,'password' => 'Парола:'
    
    ,'remember_me' => 'Запомни ме'
    ,'form_submit' => 'Вход'
    ,'forgotten_pass' => 'Забравена парола?'
];