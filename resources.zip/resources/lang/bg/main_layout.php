<?php

return [
    'title_tag' => 'Чудовища на Успеха - Админ Панел'
    ,'lang' => 'Език:'
    ,'nav_h1' => 'Админ Панел'
    ,'nav_logout' => 'Изход'

    ,'menu_dashboard' => 'Дашборд'
    ,'menu_points' => 'Точкуване'
    ,'menu_levels' => 'Нива'
    ,'menu_missions' => 'Мисии'
    ,'menu_monsters' => 'Чудовища'
];
