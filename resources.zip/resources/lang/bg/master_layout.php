<?php

return [
    'title_tag' => 'Чудовища на Успеха'
    ,'title_h1' => 'Чудовища на Успеха'
    ,'see_monster' => 'Виж Чудовище'
    
    ,'login' => 'Вход'
    ,'registration' => 'Регистрация'
    ,'logout' => 'Изход'
    ,'main_title' => 'Забавлявай се - Учи - Печели'
];