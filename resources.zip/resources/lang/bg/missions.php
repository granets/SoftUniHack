<?php

return [
    'form_mission' => 'Здайте мисия:'
    ,'form_points' => 'Задайте точки:'
    ,'form_submit' => 'Добави мисия'
    
    ,'missions_list' => 'Списък с мисии'
    ,'table_mission' => 'Мисия'
    ,'table_points' => 'Точки'
    ,'table_delete' => 'Изтрий'
    ,'td_pts' => 'точки'
    ,'td_delete' => 'Изтрий'
];