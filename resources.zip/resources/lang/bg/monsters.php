<?php

return [
    'title' => 'Чудовища'
    ,'name' => 'Име на чудовището:'
    ,'code' => 'Код:'
    ,'class' => 'Клас:'
    ,'subject' => 'Предмет:'
    ,'submit_add' => 'Добави чудовище'

    ,'table_monster' => 'Чудовище'
    ,'table_pic' => 'Картинка'
    ,'table_class' => 'Клас'
    ,'table_level' => 'Ниво'
    ,'table_points' => 'Общо точки'
    ,'table_details' => 'Подробности'
    ,'table_delete' => 'Изтрий'

    ,'td_points_str' => 'т'
    ,'td_details' => 'Подробности'
    ,'td_delete' => 'Изтрий'
];
