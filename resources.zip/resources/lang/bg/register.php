<?php

return [
    'title' => 'Регистрация'
    ,'names' => 'Име:'
    ,'email' => 'Ел. поща:'
    ,'password' => 'Парола:'
    ,'repeat_password' => 'Повтори паролата:'
    ,'form_submit' => 'Регистрирай се'
];