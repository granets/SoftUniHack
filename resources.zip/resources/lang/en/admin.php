<?php

return [
    'title_h1' => 'Dashboard'
    ,'points' => 'Points'
    ,'see_more' => 'See More'
    ,'levels' => 'Levels'
    ,'missions' => 'Missions'
    ,'monsters' => 'Monsters'
];