<?php

return [
    'title_h1' => 'Monstrous Success'
    ,'main_title' => 'Have Fun - Learn - Win'
    ,'footer_copyright' => 'Monstrous Success 2016'
];