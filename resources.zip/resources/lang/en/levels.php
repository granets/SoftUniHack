<?php

return [
    'levels_title' => 'New Level'
    ,'number' => 'Number:'
    ,'level' => 'Level:'
    ,'add_level' => 'Add Level'
    
    ,'table_title' => 'Levels List'
    ,'table_number' => 'Number'
    ,'table_levels' => 'Level'
    ,'table_delete' => 'Delete'
    ,'td_delete' => 'Delete'
];