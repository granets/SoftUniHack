<?php

return [
    'login' => 'Login'
    ,'email' => 'Email:'
    ,'password' => 'Password:'
    
    ,'remember_me' => 'Remember me'
    ,'form_submit' => 'Login'
    ,'forgotten_pass' => 'Forgotten Password?'
];