<?php

return [
    'title_tag' => 'Monstrous Success - Dashboard'
    ,'lang' => 'Language:'
    ,'nav_h1' => 'Dashboard'
    ,'nav_logout' => 'Logout'

    ,'menu_dashboard' => 'Dashboard'
    ,'menu_points' => 'Points'
    ,'menu_levels' => 'Levels'
    ,'menu_missions' => 'Missions'
    ,'menu_monsters' => 'Monsters'
];