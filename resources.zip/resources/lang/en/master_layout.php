<?php

return [
    'title_tag' => 'Monstrous Success'
    ,'title_h1' => 'Monstrous Success'
    ,'see_monster' => 'View Monsters'
    
    ,'login' => 'Login'
    ,'registration' => 'Register'
    ,'logout' => 'Logout'
];