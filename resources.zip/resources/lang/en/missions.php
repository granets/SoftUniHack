<?php

return [
    'form_mission' => 'Mission:'
    ,'form_points' => 'Points:'
    ,'form_submit' => 'Add New Mission'
    
    ,'missions_list' => 'Missions List'
    ,'table_mission' => 'Mission'
    ,'table_points' => 'Points'
    ,'table_delete' => 'Delete'
    ,'td_pts' => 'pts'
    ,'td_delete' => 'Delete'
];