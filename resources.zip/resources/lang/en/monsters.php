<?php
return [
    'title' => 'Monsters'
    ,'name' => 'Monster Name:'
    ,'code' => 'Code:'
    ,'class' => 'Class:'
    ,'subject' => 'Subject:'
    ,'submit_add' => 'Add Monster'

    ,'table_monster' => 'Monster'
    ,'table_pic' => 'Picture'
    ,'table_class' => 'Class'
    ,'table_level' => 'Level'
    ,'table_points' => 'Total Points'
    ,'table_details' => 'Details'
    ,'table_delete' => 'Delete'

    ,'td_points_str' => 'pts'
    ,'td_details' => 'Details'
    ,'td_delete' => 'Delete'
];
