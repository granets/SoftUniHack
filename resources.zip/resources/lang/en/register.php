<?php

return [
    'title' => 'Registration'
    ,'names' => 'Names:'
    ,'email' => 'Email:'
    ,'password' => 'Password:'
    ,'repeat_password' => 'Repeat Password:'
    ,'form_submit' => 'Register'
];