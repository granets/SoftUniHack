@extends('layouts.master-admin')

@section('content')
<div> 
	id = {{$id}}
</div>
@endsection